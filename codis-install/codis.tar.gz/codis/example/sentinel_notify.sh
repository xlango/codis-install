#!/bin/bash

echo $@ >> sentinel_notify.log
